MovieVerse – React Movie Explorer

MovieVerse is a React-based web application that lets users explore trending movies, search titles, filter by genres, view ratings, and maintain a personal watchlist using TMDB API.
It features dynamic UI, sorting, searching, genre filters, and watchlist management stored in LocalStorage.

Features
Search & Browse

Fetches movies from TMDB API

Real-time search with instant results

Genre Filtering

Auto-detects genres from the user’s watchlist

Filter movies by any genre dynamically

Sorting Options

Sort by ratings (ascending / descending)

Clean UI with arrow-based sorting controls

Watchlist

Add or remove movies to your personal watchlist

Saved locally using LocalStorage

Displays poster, rating, popularity & genre

Responsive UI

Built with Tailwind CSS

Fully responsive layout

Tech Stack

React.js

TMDB API

Tailwind CSS

LocalStorage

JavaScript (ES6)