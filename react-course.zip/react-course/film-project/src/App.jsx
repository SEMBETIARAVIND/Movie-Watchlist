import "./App.css";
import Banner from "./components/banner";
import Movies from "./components/Movies";
import  Navbar  from "./components/Navbar";
import WatchList from "./components/WatchList";
import React, { useEffect, useState } from 'react';


import {BrowserRouter, Routes, Route} from 'react-router-dom'

function App(){
  let [watchlist, setWatchList]=useState([])
  let handleAddtoWatchList=(movieObj)=>{
    let newWatchList=[...watchlist,movieObj]
    localStorage.setItem('moviesApp',JSON.stringify(newWatchList))
    setWatchList(newWatchList)
    console.log(newWatchList)
  }
  let  handleRemoveFromWatchList=(movieObj)=>{
    let filteredWatchList=watchlist.filter((movie)=>{
      return movie.id!=movieObj.id
    })
    setWatchList(filteredWatchList)
    localStorage.setItem('moviesApp',JSON.stringify(filteredWatchList));
  }
  useEffect(()=>{
    let moviesFromLocalStorage=localStorage.getItem('moviesApp')
    if(!moviesFromLocalStorage){
      return
    }
    else{
      setWatchList(JSON.parse(moviesFromLocalStorage))
    }
  },[])



  return (
    <>
    <BrowserRouter>
    <Navbar/>

    <Routes>
      <Route path='/' element={<><Banner></Banner><Movies watchlist={watchlist} handleAddtoWatchList={handleAddtoWatchList} handleRemoveFromWatchList={handleRemoveFromWatchList} /></>} />
    <Route 
  path='/watchlist' 
  element={
    <WatchList 
      watchlist={watchlist}
      setWatchList={setWatchList}
      handleRemoveFromWatchList={handleRemoveFromWatchList}
    />
  }
/>

    
    </Routes>

    </BrowserRouter>
    </>
  );
}


export default App
