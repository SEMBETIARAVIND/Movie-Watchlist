import React, { useEffect, useState } from 'react'
import genreids from '../utility/genre'

function WatchList({watchlist, setWatchList, handleRemoveFromWatchList}) {
  const [search,setSearch]=useState('')
  const [genreList, setgenreList]=useState(['All Genres'])
  const [cuuGenre,setcurrGenre]=useState('All Genres');

let handleSearch=(e)=>{
setSearch(e.target.value)
};
let handleFilter=(genre)=>{
  setcurrGenre(genre)
}
let sortIncreasing =()=>{
let sortedIncreasing = watchlist.sort((movieA,MovieB)=>{
  return movieA.vote_average - MovieB.vote_average
})
setWatchList([...sortedIncreasing])
}
let sortDecreasing=()=>{
let sortedDecreasing= watchlist.sort((movieA,MovieB)=>{
  return MovieB.vote_average - movieA.vote_average
})
setWatchList([...sortedDecreasing])
}
useEffect(()=>{
  let temp=watchlist.map((movieObj)=>{
    return genreids[movieObj.genre_ids[0]]
  })
  temp = new Set(temp)
  setgenreList(['All Genres',...temp])
},[watchlist])

  return (
    <>
    <div className='flex justify-center flex-wrap m-4'>
      {genreList.map((genre)=>{
 return <div onClick={()=>handleFilter(genre)} className={cuuGenre==genre?'flex justify-center items-center h-[3rem] w-[9rem] bg-blue-400 rounded-xl text-white font-bold mx-4':'flex justify-center items-center h-[3rem] w-[9rem] bg-gray-400/50 rounded-xl text-white font-bold mx-4 '}>{genre}</div>
      })}
      

      
    </div>




    <div className='flex justify-center my-4'>
      <input onChange={handleSearch} value={search} type="text" placeholder='Search For Movies' className='h-[3rem] w[18rem] bg-gray-200 outline-none px-4' />
    </div>
    <div className='overflow-hidden rounded-lg border border-gray-200 m-8'>
      <table className='w-full text-black-500 text-center'>
        <thead className='border-b-2'>
          <tr>
            <th>Name</th>
            <th className='flex justify-center'>
              <div onClick={sortIncreasing} className='p-2'><i class="fa-solid fa-arrow-up"></i></div>
              <div className='p-2'>Ratings</div>
              <div onClick={sortDecreasing} className='p-2'><i class="fa-solid fa-arrow-down"></i></div>
            </th>
            
            <th>Popularity</th>
            <th>Genre</th>
          </tr>
        </thead>
        <tbody>
          {watchlist.filter((movieObj)=>{
            if(cuuGenre=='All Genres'){
              return true
            }
            else{
              return genreids[movieObj.genre_ids[0]]==cuuGenre;
            }
          }).filter((movieObj)=>{
            return movieObj.title.toLowerCase().includes(search.toLocaleLowerCase())
          }).map((movieObj)=>{
            return <tr className='border-b-2'>
            <td className='flex items-center px-6 py-4'>
              <img className="h-30 w-20 object-cover rounded-md" src={`https://image.tmdb.org/t/p/original/${movieObj.poster_path}
`} />
              <div className='mx-10'>{movieObj.title}</div>
            </td>
            <td>{movieObj.vote_average}</td>
            <td>{movieObj.popularity}</td>
            <td>{genreids[movieObj.genre_ids[0]]}</td>
            <td onClick={()=>handleRemoveFromWatchList(movieObj)} className='text-red-800'>Delete</td>
          </tr>
          })}



          


          
        </tbody>
      </table>
    </div>
    </>
  )
}

export default WatchList