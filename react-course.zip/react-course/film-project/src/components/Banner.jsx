import React from 'react'

function Banner() {
  return (
    <div className='h-[20vh] md:h-[75vh] bg-cover bg-center flex items-end' style={{backgroundImage:`url(https://img00.deviantart.net/d681/i/2012/077/0/0/____the_avengers_____banner_3_by_andrewss7-d4t4n6x.jpg)`}}>
        <div className='text-white text-2xl text-center w-full bg-blue-900/60 p-4'>Avengers</div>
    </div>
  )
}

export default Banner